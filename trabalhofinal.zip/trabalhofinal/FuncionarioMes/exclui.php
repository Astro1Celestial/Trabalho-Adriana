<?php

$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "dbempresa";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $funcionario = $_POST['func'] ?? ""; 


    if (!empty($funcionario) && $funcionario !== "Escolha um Funcionário") {
 
        $sql = "DELETE FROM tbfuncmes WHERE nome = ?"; 
        
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("s", $funcionario); 

            if ($stmt->execute()) {
                $mensagem = "Funcionário '$funcionario' excluído com sucesso!";
            } else {
                $mensagem = "Erro ao excluir o funcionário: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $mensagem = "Erro na preparação da query: " . $conn->error;
        }
    } else {
        $mensagem = "Por favor, selecione um funcionário.";
    }
}

$sql = "SELECT nome FROM tbfuncmes";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exclusão de Funcionário</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="container">
    <br>
    <button><a href="javascript: history.back()">Voltar</a></button>
    <h2>EXCLUSÃO</h2>
    <br>

    <?php

    if (!empty($mensagem)) {
        echo "<div class='alert alert-info'>$mensagem</div>";
    }
    ?>

    <form method="POST" id="form1" name="form1" action="" enctype="multipart/form-data">
        <div class="col-lg-7 mx-auto">
            <div class="form-group">
                <b>Escolha o Funcionário que você deseja excluir:</b>
                <select class="form-control w-50" id="func" name="func" required="required">
                <?php
                    
                    if ($result->num_rows > 0) {
                        
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['nome'] . "'>" . $row['nome'] . "</option>";
                        }
                    } else {
                        echo "<option value=''> Nenhum funcionário encontrado </option>";
                    }
                    ?>
                </select>
                <br>

                <button class="btn btn-primary btn-xl" id="exclui" name="exclui" type="submit">Excluir</button>
                <br><br>
            </div>
        </div>
    </form>
</div>

</body>
</html>
