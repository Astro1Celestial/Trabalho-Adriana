<?php

$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "dbempresa";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

$mensagem = "";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $funccodigo = $_POST['func'];
        $novo_nome = $_POST['novo_nome'];
        $novo_vrvenda = $_POST['novo_vrvenda'];
        $novo_vrbonus = $_POST['novo_vrbonus'];
        $novo_caminhoimg = $_POST['novo_caminhoimg'];
        $novo_mes = $_POST['novo_mes'];
        $novo_ano = $_POST['novo_ano'];

        if (!empty($funccodigo) && !empty($novo_nome) && !empty($novo_vrvenda) && !empty($novo_vrbonus) && !empty($novo_caminhoimg) && !empty($novo_mes) && !empty($novo_ano)) {
            
            $sql = "UPDATE tbfuncmes SET nome = ?, vrvenda = ?, vrbonus = ?, caminhoimg = ?, mes = ?, ano = ? WHERE nome = ?";
            
            $stmt = $conn->prepare($sql);
    
            if ($stmt) {
                $stmt->bind_param("sssssss", $novo_nome, $novo_vrvenda, $novo_vrbonus, $novo_caminhoimg, $novo_mes, $novo_ano, $funccodigo);  
    
                if ($stmt->execute()) {
                    $mensagem = "Funcionário '$funccodigo ' alterado com sucesso!";
                } else {
                    $mensagem = "Erro ao alterar o funcionário: " . $stmt->error;
                }
    
                $stmt->close();
            } else {
                $mensagem = "Erro na preparação da query: " . $conn->error;
            }
        } else {
            $mensagem = "Por favor, preencha todos os campos.";
        }
    }

$sql = "SELECT nome FROM tbfuncmes";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de Funcionário</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="container">
    <br>
    <button><a href="javascript: history.back()">Voltar</a></button>
    <h2>Alteração</h2>
    <br>

    <?php

    if (!empty($mensagem)) {
        echo "<div class='alert alert-info'>$mensagem</div>";
    }
    ?>

    <form method="POST" id="form1" name="form1" action="" enctype="multipart/form-data">
        <div class="col-lg-7 mx-auto">
            <div class="form-group">
                <b>Escolha o Funcionário que você deseja alterar:</b>
                <select class="form-control w-50" id="func" name="func" required="required">
                <option value="">Escolha um Funcionário</option>
                <?php
                    
                    if ($result->num_rows > 0) {
                        
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['nome'] . "'>" . $row['nome'] . "</option>";
                        }
                    } else {
                        echo "<option value=''> Nenhum funcionário encontrado </option>";
                    }
                    ?>
                </select>
                <br>

                <label for="novo_nome">Novo Nome:</label>
                <input type="text" class="form-control" id="novo_nome" name="novo_nome" required>
                
                <label for="novo_cargo">Novo Valor Venda:</label>
                <input type="text" class="form-control" id="novo_vrvenda" name="novo_vrvenda" required>

                <label for="novo_cargo">Novo Valor Bonus:</label>
                <input type="text" class="form-control" id="novo_vrbonus" name="novo_vrbonus" required>

                <label for="novo_cargo">Novo Caminho da Imagem:</label>
                <input type="text" class="form-control" id="novo_caminhoimg" name="novo_caminhoimg" required>

                <label for="novo_cargo">Novo Mês:</label>
                <input type="text" class="form-control" id="novo_mes" name="novo_mes" required>

                <label for="novo_cargo">Novo Ano:</label>
                <input type="text" class="form-control" id="novo_ano" name="novo_ano" required>
                
                <br><br>
                <button class="btn btn-primary btn-xl" id="exclui" name="exclui" type="submit">Alterar</button>
                <br><br>
            </div>
        </div>
    </form>
</div>

</body>
</html>
